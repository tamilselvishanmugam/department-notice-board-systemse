const KEY = "dnb_notices", SESSION = "dnb_admin", PASSWORD = "admin123"; // demo only
const CATS = ["Exam", "Event", "Holiday", "Placement", "General"];
const COLORS = { Exam: "#c0392b", Event: "#2f6db5", Holiday: "#3e8e63", Placement: "#8a4f8f", General: "#b8860b" };
const $ = id => document.getElementById(id);
const day = n => { const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };

const seed = () => [
  { id: 1, title: "Internal Assessment I schedule", cat: "Exam", body: "IA-I begins next week. Timetable and seating plan are on the department door. Carry your ID card.", posted: day(-2), expires: day(10), pinned: true },
  { id: 2, title: "Technical symposium: Code Fest", cat: "Event", body: "Registrations are open for coding, debugging and paper presentation events. Meet your class representative to register.", posted: day(-1), expires: day(14), pinned: false },
  { id: 3, title: "Campus placement drive", cat: "Placement", body: "Final-year students with no arrears can register with the placement cell before the deadline.", posted: day(-4), expires: day(6), pinned: false },
  { id: 4, title: "Holiday on account of festival", cat: "Holiday", body: "The department will remain closed. Classes resume on the next working day.", posted: day(-8), expires: day(-1), pinned: false }
];

let notices = load(), isAdmin = sessionStorage.getItem(SESSION) === "1", editId = null;

function load() {
  try { return JSON.parse(localStorage.getItem(KEY)) || seed(); } catch { return seed(); }
}
function save() { localStorage.setItem(KEY, JSON.stringify(notices)); }
function esc(s) { return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
const fmt = d => new Date(d + "T00:00").toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });

function fillSelects() {
  $("cat").innerHTML = '<option value="">All categories</option>' + CATS.map(c => `<option>${c}</option>`).join("");
  $("fCat").innerHTML = CATS.map(c => `<option>${c}</option>`).join("");
}

function render() {
  const q = $("q").value.trim().toLowerCase(), cat = $("cat").value, today = day(0);
  const list = notices
    .filter(n => (!cat || n.cat === cat) && (!q || (n.title + " " + n.body).toLowerCase().includes(q)))
    .sort((a, b) => (b.pinned - a.pinned) || b.posted.localeCompare(a.posted));
  $("count").textContent = list.length + (list.length === 1 ? " notice" : " notices");
  $("board").innerHTML = list.length ? list.map(n => {
    const expired = n.expires && n.expires < today;
    return `<article class="notice${expired ? " expired" : ""}" style="--tape:${COLORS[n.cat]};--tape-text:${COLORS[n.cat]}">
      ${n.pinned ? '<span class="pin">Pinned</span>' : ""}
      <h2>${esc(n.title)}</h2><p>${esc(n.body)}</p>
      <div class="meta"><span><span class="tag">${esc(n.cat)}</span> · Posted ${fmt(n.posted)}${n.expires ? (expired ? " · Expired" : " · Until " + fmt(n.expires)) : ""}</span></div>
      ${isAdmin ? `<div class="actions"><button data-edit="${n.id}">Edit</button><button data-del="${n.id}">Delete</button></div>` : ""}
    </article>`;
  }).join("") : '<p class="empty">No notices match your search.</p>';
}

function syncAdminUI() {
  $("newBtn").hidden = !isAdmin;
  $("loginBtn").textContent = isAdmin ? "Log out" : "Staff login";
  render();
}

function openForm(n) {
  editId = n ? n.id : null;
  $("formTitle").textContent = n ? "Edit notice" : "Post notice";
  $("fTitle").value = n ? n.title : "";
  $("fCat").value = n ? n.cat : CATS[0];
  $("fBody").value = n ? n.body : "";
  $("fExp").value = n ? n.expires || "" : "";
  $("fPin").checked = n ? n.pinned : false;
  $("formDlg").showModal();
}

$("q").addEventListener("input", render);
$("cat").addEventListener("change", render);
$("newBtn").addEventListener("click", () => openForm(null));
$("loginBtn").addEventListener("click", () => {
  if (isAdmin) { isAdmin = false; sessionStorage.removeItem(SESSION); syncAdminUI(); }
  else { $("pass").value = ""; $("loginErr").hidden = true; $("loginDlg").showModal(); }
});
document.querySelectorAll("[data-close]").forEach(b => b.addEventListener("click", () => b.closest("dialog").close()));

$("loginForm").addEventListener("submit", e => {
  e.preventDefault();
  if ($("pass").value === PASSWORD) { isAdmin = true; sessionStorage.setItem(SESSION, "1"); $("loginDlg").close(); syncAdminUI(); }
  else $("loginErr").hidden = false;
});

$("noticeForm").addEventListener("submit", e => {
  e.preventDefault();
  const data = { title: $("fTitle").value.trim(), cat: $("fCat").value, body: $("fBody").value.trim(), expires: $("fExp").value, pinned: $("fPin").checked };
  if (editId) notices = notices.map(n => n.id === editId ? { ...n, ...data } : n);
  else notices.push({ id: Date.now(), posted: day(0), ...data });
  save(); $("formDlg").close(); render();
});

$("board").addEventListener("click", e => {
  const ed = e.target.dataset.edit, del = e.target.dataset.del;
  if (ed) openForm(notices.find(n => n.id == ed));
  if (del && confirm("Delete this notice?")) { notices = notices.filter(n => n.id != del); save(); render(); }
});

fillSelects();
syncAdminUI();
