# Department Notice Board System

Pure HTML, CSS and JavaScript. No install and no server needed.

## Run
Open `index.html` in any browser.

## Features
- Notice cards with category, posted date, expiry date and pin-to-top
- Search and category filter
- Staff login (password: `admin123`) to post, edit and delete notices
- Expired notices are dimmed and marked
- Responsive layout

## Files
- `index.html` page structure
- `style.css` styling
- `app.js` notice logic (data is stored in the browser's localStorage)

## Note
This is a front-end demo. The password and notices live in the browser, so it is not secure
for real use. For production, add a backend (Node/Express, Django or PHP) with a database
and proper authentication, then replace the localStorage calls in `app.js` with API calls.
